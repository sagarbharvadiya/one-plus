import React from "react";

function Test(){
    return(
        <>
        {/* SECOND SCROLL */}
            <div className="what-Make-Us-section test-example">
            
                <div className="container">
                <div className="what-Make-Us-whapper d-flex flex-column justify-content-start align-items-start test-example-content">
                   
                <h2 className="pb-4">A multi-cultural team that designs <b> unique solutions for you</b></h2>
                    
                </div>
                </div>
            </div>
        </>
    )
};

export default Test;